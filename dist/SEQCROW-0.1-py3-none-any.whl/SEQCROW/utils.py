"""random functions that are used more than once"""
def iter2str(t):
    """converts tuple to str and cuts off ()"""
    return str(t)[1:-1]