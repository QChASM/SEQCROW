import time

from unittest import TestCase

from chimerax.core.toolshed import BundleAPI
from chimerax.core.commands import register



class TestWithSession(TestCase):
    count = 0
    total_time = 0
    last_class = None
    last_result = None
    _errors = 0
    _fails = 0
    _session = None
    _prev_msg = ""
    _prev_test = ""

    def addTests(self, suite):
        test_names = [
            key for key in self.__class__.__dict__.keys() if key.startswith("test_")
        ]
        for test in test_names:
            if callable(getattr(self, test)):
                suite.addTest(self.__class__(test))
    
    @classmethod
    def tearDownClass(cls):
        errors = len(cls.last_result.errors)
        fails = len(cls.last_result.failures)
        ok_msg = "{} ok"
        if TestWithSession._errors != errors:
            TestWithSession._errors = errors
            ok_msg = "{} ERROR"
        elif TestWithSession._fails != fails:
            TestWithSession._fails = fails
            ok_msg = "{} FAIL"
        else:
            ok_msg = "{} ok"

        TestWithSession._prev_msg += ok_msg.format(TestWithSession._prev_test)
        TestWithSession._prev_test = ""

        cls._session.logger.info(
            "<pre>{}</pre>".format(TestWithSession._prev_msg),
            is_html=True,
            add_newline=False,
        )

        cls._session.logger.info(
            "<pre>Ran {} tests in {:.3f}s</pre>".format(
                TestWithSession.count,
                TestWithSession.total_time,
            ),
            is_html=True,
        )
        cls._session.logger.info("-" * 70)
        TestWithSession.total_time = 0
        TestWithSession.count = 0
        TestWithSession.last_class = None

    def setUp(self):
        errors = len(self._outcome.result.errors)
        fails = len(self._outcome.result.failures)
        ok_msg = "{} ok"
        if TestWithSession._errors != errors:
            TestWithSession._errors = errors
            ok_msg = "{} ERROR"
        elif TestWithSession._fails != fails:
            TestWithSession._fails = fails
            ok_msg = "{} FAIL"
        elif self.id().split(".")[1] == self.last_class:
            ok_msg = "{} ok"
        if TestWithSession._prev_test:
            TestWithSession._prev_msg += ok_msg.format(TestWithSession._prev_test)
        self.start_time = time.time()

    def tearDown(self):
        t = time.time() - self.start_time
        TestWithSession.total_time += t

        name = self.id().split(".")[-2:]
        if not TestWithSession.last_class or TestWithSession.last_class != name[0]:
            TestWithSession.last_class = name[0]
            TestWithSession.count = 0
            TestWithSession._prev_msg = "\n{}:".format(name[0])

        name = name[1]
        TestWithSession.count += 1
        TestWithSession._prev_test = "\n    {:3.0f}: {:<30s} {: 3.3f}s  ".format(
            TestWithSession.count, name, t
        )

        TestWithSession.last_result = self._outcome.result


class _TESTCROW_API(BundleAPI):

    api_version = 1
    
    @staticmethod
    def initialize(session, bundle_info):
        TestWithSession._session = session
    
    @staticmethod
    def register_command(bundle_info, command_info, logger):
        if command_info.name == "test":
            from .commands.test import test, test_description
            register("test", test_description, test)

    
bundle_api = _TESTCROW_API()
