def rmsd_tol(struc, superTight=False, superLoose=False):
    """
    Automatically determine a reasonable rmsd tolerance for the input
    AtomicStructure based on its size and number of atoms
    """
    import numpy as np
    tolerance = struc.num_atoms ** (
        2 - int(superTight) + int(superLoose)
    ) * np.sqrt(np.finfo(float).eps)

    com = np.mean(struc.active_coordset.xyzs, axis=0)
    max_d = None
    for atom in struc.atoms:
        d = np.linalg.norm(atom.coord - com)
        if max_d is None or d > max_d:
            max_d = d

    tolerance *= max_d * (2 - int(superTight) + int(superLoose))
    tolerance = tolerance ** (2 / (4 - int(superTight) + int(superLoose)))
    return tolerance


def check_atom_list(ref, comp):
    rv = True
    for i, j in zip(ref, comp):
        rv &= i.__repr__() == j.__repr__()
    return rv


def validate_atomic_structures(test, ref, thresh=None, debug=False):
    """
    Validates `test` atomic structure against `ref` atomic structure
    Returns: True if validation passed, False if failed

    :test: the atomic structure to validate
    :ref: the reference atomic structure
    :thresh: the RMSD threshold
        if thresh is a number: use that as threshold
        if thresh is None: use rmsd_tol() to determine
        if thresh is "tight": use rmsd_tol(superTight=True)
        if thresh is "loose": use rmsd_tol(superLoose=True)
    :debug: print info useful for debugging
    """
    import numpy as np

    if debug:
        print("ref and test:")
        for mol in [ref, test]:
            print(mol.num_atoms)
            for atom in mol.atoms:
                print(" %-10s    %6.3f    %6.3f    %6.3f" % (atom.atomspec, atom.coord[0], atom.coord[1], atom.coord[2]))

    if thresh is None:
        thresh = rmsd_tol(ref)
    try:
        thresh = float(thresh)
    except ValueError:
        if thresh.lower() == "tight":
            thresh = rmsd_tol(ref, superTight=True)
        elif thresh.lower() == "loose":
            thresh = rmsd_tol(ref, superLoose=True)
        else:
            raise ValueError("Bad threshold provided")

    # elements should all be the same
    t_el = test.atoms.elements.names.tolist()
    r_el = ref.atoms.elements.names.tolist()
    if len(t_el) != len(r_el):
        if debug:
            print(
                "wrong number of atoms: {} (test) vs. {} (ref)".format(
                    len(t_el), len(r_el)
                )
            )
        return False

    for t, r in zip(t_el, r_el):
        if t != r:
            if debug:
                print("elements don't match")
            return False
    # and RMSD should be below a threshold
    
    ref_coords = ref.active_coordset.xyzs
    ref_coords -= np.mean(ref_coords, axis=0)
    test_coords = test.active_coordset.xyzs
    test_coords -= np.mean(test_coords, axis=0)
    
    if debug:
        print("ref centered:")
        for atom, coord in zip(ref.atoms, ref_coords):
                print(" %-10s    %6.3f    %6.3f    %6.3f" % (atom.atomspec, coord[0], coord[1], coord[2]))
        print("test centered:")
        for atom, coord in zip(test.atoms, test_coords):
                print(" %-10s    %6.3f    %6.3f    %6.3f" % (atom.atomspec, coord[0], coord[1], coord[2]))

    H = np.dot(ref_coords.T, test_coords)
    u, s, vh = np.linalg.svd(H, compute_uv=True)
    d = 1.
    if np.linalg.det(np.matmul(vh.T, u.T)) < 0:
        d = -1.
    m = np.diag([1., 1., d])
    R = np.matmul(vh.T, m)
    R = np.matmul(R, u.T)

    aligned_coords = np.dot(test_coords, R)
    
    diff = ref_coords - aligned_coords
    rmsd = 0
    for coord in diff:
        rmsd += np.dot(coord, coord)
    
    rmsd /= test.num_atoms
    rmsd = np.sqrt(rmsd)
    
    if debug:
        print("RMSD:", rmsd, "\tTHRESH:", thresh)
        print(test.num_atoms)
        for atom, new_coord in zip(test.atoms, aligned_coords):
            print(" %-10s    %6.3f    %6.3f    %6.3f" % (atom.atomspec, new_coord[0], new_coord[1], new_coord[2]))

    return rmsd < thresh
