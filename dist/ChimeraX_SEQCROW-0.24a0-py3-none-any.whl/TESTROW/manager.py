from warnings import warn

from chimerax.core.toolshed import ProviderManager

from TESTROW import TestWithSession

class TestManager(ProviderManager):
    def __init__(self, session, name):
        self._session = session
        self.tests = {}
        super().__init__(name)

    def add_provider(self, bundle_info, name):
        self.tests[name] = bundle_info
