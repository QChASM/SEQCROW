import os.path

from AaronTools.test import prefix, validate
from chimerax.core.commands import run
from SEQCROW.tools import NormalModes
from TESTROW import TestWithSession


class NormalModesToolTest(TestWithSession):
    
    formaldehyde = os.path.join(prefix, "test_files", "freq.log")

    def test_show_vec(self):
        run(self.session, "open %s" % self.formaldehyde)
        run(self.session, "ui tool show \"Visualize Normal Modes\"")
        
        for tool in self.session.tools.list():
            if isinstance(tool, NormalModes):
                normal_mode_tool = tool
                break
        else:
            # normal mode tool didn't open
            self.assertTrue(False)
        
        normal_mode_tool.show_vec_button.click()
        self.assertTrue(len(self.session.models.list()) == 2)
        
        normal_mode_tool.close_vec_button.click()
        self.assertTrue(len(self.session.models.list()) == 1)

        normal_mode_tool.delete()

    def test_show_anim(self):
        run(self.session, "open %s" % self.formaldehyde)
        run(self.session, "ui tool show \"Visualize Normal Modes\"")
        
        for tool in self.session.tools.list():
            if isinstance(tool, NormalModes):
                normal_mode_tool = tool
                break
        else:
            # normal mode tool didn't open
            self.assertTrue(False)
        
        normal_mode_tool.show_anim_button.click()
        self.assertTrue(len(self.session.models.list()) == 1)

        mdl = self.session.models.list()[0]
        self.assertTrue(mdl.num_coordsets == normal_mode_tool.anim_duration.value())
        
        normal_mode_tool.delete()
