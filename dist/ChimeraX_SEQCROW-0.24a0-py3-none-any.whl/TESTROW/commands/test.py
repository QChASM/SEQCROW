from chimerax.core.commands import CmdDesc, DynamicEnum, ListOf, register

def get_test_names(session):
    names = ["all"]
    for name in session.test_manager.tests:
        names.append(name)
    
    return names

def register_test_command(logger):
    desc = CmdDesc(
        optional=[(
            "test_names",
            ListOf(
                DynamicEnum(
                    lambda session=logger.session: get_test_names(session)
                )
            )
        )],
        synopsis="test the specifed component or 'all'",
    )
    
    register("test", desc, test)

def test(session, test_names=["all"]):
    from unittest import TestSuite, TextTestRunner
    
    suite = TestSuite()
    runner = TextTestRunner()    
    
    if any(name == "all" for name in test_names):
        names = get_test_names(session)[1:]
    else:
        names = test_names
    
    for name in names:
        session.test_manager.tests[name].run_provider(session, name, session.test_manager).addTests(suite)
    
    runner.run(suite)