import unittest

from chimerax.core.commands import CmdDesc, EnumOf

test_description = CmdDesc(
    required=[("name", EnumOf([
        "substituteCmd",
        ]))],
    synopsis="test the specified component",
)

def test(session, name):
    session.logger.info("running %s test" % name)
    
    suite = unittest.TestSuite()
    
    if name == "substituteCmd":
        from TESTROW.tests.substitute_command import SubstituteCmdTest
        SubstituteCmdTest().addTests(suite)
    
    runner = unittest.TextTestRunner()
    runner.run(suite)