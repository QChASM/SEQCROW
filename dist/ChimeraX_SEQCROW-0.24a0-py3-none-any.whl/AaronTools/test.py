from AaronTools.fileIO import FileReader
from AaronTools.theory import OptimizationJob
from AaronTools.geometry import Geometry


"""
geom = Geometry("test.xyz")
geom.detect_components()

for comp in geom.components:
    if len(comp.atoms) == 1:
        continue
    
    print(comp.cone_angle(center=geom.center))
"""

fr = FileReader("constrained_opt.log", just_geom=False)

theory = fr.other["theory"]
for job in theory.job_type:
    if isinstance(job, OptimizationJob):
        for key in job.constraints:
            print(key)
            for const in job.constraints[key]:
                print("\t", const)
                
geom = Geometry(fr)

print(geom.write(style="com", theory=fr.other["theory"], outfile=False))