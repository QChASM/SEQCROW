from AaronTools.geometry import Geometry

geom = Geometry("test.xyz")
geom.detect_components()

for comp in geom.components:
    if len(comp.atoms) == 1:
        continue
    
    print(comp.cone_angle(center=geom.center))