from AaronTools.geometry import Geometry
from AaronTools.theory import Theory, OptimizationJob
from AaronTools.fileIO import FileReader

geom = Geometry("test.xyz")

const = {
    # specifying 'hold' (the third parameter) is optional and defaults to False
    # we could instead specify "z": ["1-5"], though this would create a new variable
    # for each coordinate
    # "z": ["1-5"],
    # "zgroup": [(["1-5"], 0.0, True), (["11-16"], 3.23662)], 
}

theory = Theory(
    job_type=OptimizationJob(constraints=const),
    method="wB97X-D",
    basis="def2-TZVP",
    route={"opt":["maxcycles=300"], "NoSymmetry": None},
)

print(geom.write(outfile=False, theory=theory, style="orca"))

# fr = FileReader("zmat6.log", just_geom=False)
# for param in fr.other["params"]:
#     print("%3s = %10.5f" % param)