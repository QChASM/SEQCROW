from TestManager import TestWithSession
from chimerax.core.commands import run

class Test(TestWithSession):
    close_between_tests = False
    close_between_classes = False

    @classmethod
    def setUpClass(cls):
        cls.struc = run(cls.session, "open 2efv")[0]
        super(Test, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        cls.struc.delete()
        super(Test, cls).tearDownClass()
    
    def runTest(self):
        self.session.logger.info(self.struc.atomspec)