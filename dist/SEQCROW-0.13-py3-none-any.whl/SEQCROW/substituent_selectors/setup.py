#!/usr/bin/env python3

import numpy
from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize

ext_modules = [Extension("cy_selectors", ["cy_selectors.pyx"], \
                         include_dirs=[numpy.get_include()], \
                         extra_link_args=[])]

setup(ext_modules=cythonize(ext_modules))

