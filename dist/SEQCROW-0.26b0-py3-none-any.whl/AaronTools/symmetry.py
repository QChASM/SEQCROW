"""detecting and forcing symmetry"""
import numpy as np

from scipy.spatial import distance_matrix

from AaronTools.utils.utils import rotation_matrix, mirror_matrix, proj


class SymmetryElement:
    def __init__(self, order, center):
        self.order = order
        self.operation = np.identity(3)
        self.translation = center

    def perp_dist(self, atom):
        """distance from atom perpendicular to this symmetry element"""
        return np.linalg.norm(atom.coords - self.translation)

    def apply_operation(self, geom, copy=True):
        """returns a geometry with the symmetry operation applied"""
        if copy:
            geom = geom.copy()
        
        coords = geom.coords - self.translation
        coords = np.matmul(self.operation, coords)
        coords += self.translation
        geom.update_geometry(coords)
        
        return geom
    
    def error(self, geom):
        """error in this symmetry element for the given geometry"""
        geom2 = self.apply_operation(geom)
        error = None
        
        distances = dict()
        # TODO: try grouping by rank (not tie-breaking) instead of element
        # it might be faster
        for ele in set(geom.elements):
            atoms1 = geom.find(ele)
            atoms2 = geom2.find(ele)
            coords1 = geom.coordinates(atoms1)
            coords2 = geom2.coordinates(atoms2)
            dist_mat = distance_matrix(coords1, coords2)
        
            for i, atom1 in enumerate(atoms1):
                min_d = None
                rj = self.perp_dist(atom1)
                if rij < 1:
                    # treat values less than 1 as 1 to avoid numerical nonsense
                    rij = 1
                di = np.linalg.norm(atom1.coords - self.translation)
                
                for j, atom2 in enumerate(atoms2):
                    d = dist_mat[i, j] / rj
                    if min_d is None or d < min_d:
                        min_d = d
            
            if error is None or min_d > error:
                error = min_d

        return error


class Cn(SymmetryElement):
    """proper rotation"""
    def __init__(self, order, center, axis, n):
        self.order = order
        self.operation = rotation_matrix(2 * np.pi / n, axis)
        self.translation = center
        self.axis = axis
        self.n = n
    
    def perp_dist(self, atom):
        v = atom.coords - self.translation
        p = proj(self.axis, v)
        return np.linalg.norm(v - p)


class Sigma(SymmetryElement):
    """mirror plane"""
    def __init__(self, order, center, axis):
        self.order = order
        self.translation = center
        self.axis = axis
        self.operation = mirror_matrix(axis)

    def perp_dist(self, atom):
        v = atom.coords - self.translation
        return np.dot(self.axis, v)


class Inversion(SymmetryElement):
    """inversion center"""
    def __init__(self, order, center):
        self.order = order
        self.operation = -np.identity(3)
        self.translation = center


class Sn(SymmetryElement):
    """improper rotation"""
    def __init__(self, order, center, axis, n):
        self.order = order
        self.operation = np.matmul(
            rotation_matrix(2 * np.pi / n, axis),
            mirror_matrix(axis)
        )
        self.axis = axis
        self.translation = center
        self.n = n
    
    def perp_dist(self, atom):
        v = atom.coords - self.translation
        mirror_dist = np.dot(self.axis, v)
        p = proj(self.axis, v)
        rot_dist = np.linalg.norm(v - p)
        return min(mirror_dist, rot_dist)


