from AaronTools.geometry import Geometry
from AaronTools.finders import NotAny
from AaronTools.theory import *
from time import perf_counter


#geom = Geometry("test/ref_files/lig_map_3.xyz")
geom = Geometry("test.xyz")

m1 = geom.find("1,2")
m2 = geom.find("3,4")
m3 = geom.find("5-19")

monomers = [m1, m2, m3]

theory = Theory(
            method=Method("fisapt0", sapt=True),
            basis="jun-cc-pvdz",
            charge=[0, 0, 0, 0],
            multiplicity=[1, 2, 2, 1],
            job_type=SinglePointJob()
)

kwargs = {"settings":{"scf_type":["df"], "guess":["sad"], "freeze_core":["true"]}}

print(geom.write(outfile="test.in", theory=theory, monomers=monomers, style="psi4", **kwargs))


#
#start = perf_counter()
#print(geom.percent_buried_volume())
#print(perf_counter() - start)

#        atoms_within_radius = []
#        for lig in ligands:
#            for atom in lig:
#                d = center.dist(atom)
#                if d - radii_dict[atom.element] < radius:
#                    atoms_within_radius.append(atom)
#        
#        for i, atom in enumerate(atoms_within_radius):
#            for point in grid[::-1]:
#                dp = np.linalg.norm(point - atom.coords)
#                if dp < radii_dict[atom.element]:
#                    grid.remove(point)
#        
#            n = int(n_grid * (radii_dict[atom.element] / radius)**2)
#            atom_grid = utils.fibonacci_sphere(
#                radius=radii_dict[atom.element], 
#                center=atom.coords, 
#                n=n,
#            ).tolist()
#            
#            for point in atom_grid[::-1]:
#                dp = np.linalg.norm(center.coords - point)
#                if dp > radius:
#                    atom_grid.remove(point)
#                    continue
#                
#                for atom2 in atoms_within_radius:
#                    if atom is atom2:
#                        continue
#                    
#                    dp = np.linalg.norm(atom2.coords - point)
#                    if dp - radii_dict[atom.element] < radii_dict[atom2.element] and dp < radii_dict[atom2.element]:
#                        atom_grid.remove(point)
#                        break
#            
#            grid.extend(atom_grid)        
#
#        grid = np.array(grid)