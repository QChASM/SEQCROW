these files contain data from https://doi.org/10.1021/acs.inorgchem.8b01133

data has been processed to reduce the file size

instead of mol files, these files contain the indices for mapping ligands
onto the AaronTools VSEPR shapes

The numbering has been changed to be consistent with the AaronTools
order of positions around the VSEPR shapes in the cases where Simas'
ordering differs from ours