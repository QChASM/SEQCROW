import re

import numpy as np 

from Qt.QtCore import QLocale
from Qt.QtGui import (
    QValidator,
)
from Qt.QtWidgets import (
    QSpinBox,
    QDoubleSpinBox,
)


def getMantissaCharacteristic(value, decimals=0):
    try:
        characteristic = 0 if value == 0 else int(np.log10(abs(value)))
    except (ValueError, OverflowError):
        characteristic = 0

    # need to round now, otherwise we can get like
    # 10.00e2 instead of 1.00e3
    mantissa = value / (10 ** characteristic)
    if decimals:
        mantissa = round(mantissa, decimals + 1)
    if abs(mantissa) < 1 and abs(mantissa) > 0:
        mantissa *= 10
        characteristic -= 1
    
    return mantissa, characteristic

def validateScientific(text, ndx, minimum, maximum, prefix, suffix, decimals, hasFocus):
    match = re.match(
        "(?:%s)?(-?\d+(?:\.\d{0,%i})?(?:[Ee]-?\d+)?)(?:%s)?$" % (prefix, decimals, suffix),
        text, re.MULTILINE\
    )
    if match:
        val = float(match.group(1))
        if val < minimum or val > maximum:
            if hasFocus:
                return (QValidator.Intermediate, text, ndx)
            return (QValidator.Invalid, text, ndx)
        return (QValidator.Acceptable, text, ndx)
    
    if re.match("-?\d+(?:\.(?:\d{,%i}?(?:[Ee]-?)?))?$" % decimals, text, re.MULTILINE) or not text:
        return (QValidator.Intermediate, text, ndx)
    if re.match("-?\d+(?:[Ee]-?)$", text, re.MULTILINE) or not text:
        return (QValidator.Intermediate, text, ndx)
    if re.match("-?\d+\.$", text, re.MULTILINE) or not text:
        return (QValidator.Intermediate, text, ndx)
    
    return (QValidator.Invalid, text, ndx)
    

class FPSSpinBox(QSpinBox):
    """spinbox that makes sure the value goes evenly into 60"""
    def validate(self, text, pos):
        if pos < len(text) or pos == 0:
            return (QValidator.Intermediate, text, pos)
        
        try:
            value = int(text)
        except:
            return (QValidator.Invalid, text, pos)
        
        if 60 % value != 0:
            if pos == 1:
                return (QValidator.Intermediate, text, pos)
            else:
                return (QValidator.Invalid, text, pos)
        elif value > self.maximum():
            return (QValidator.Invalid, text, pos)
        elif value < self.minimum():
            return (QValidator.Invalid, text, pos)
        else:
            return (QValidator.Acceptable, text, pos)
    
    def fixUp(self, text):
        try:
            value = int(text)
            new_value = 1
            for i in range(1, value+1):
                if 60 % i == 0:
                    new_value = i
            
            self.setValue(new_value)
        
        except:
            pass
    
    def stepBy(self, step):
        val = self.value()
        while step > 0:
            val += 1
            while 60 % val != 0:
                val += 1
            step -= 1
        
        while step < 0:
            val -= 1
            while 60 % val != 0:
                val -= 1
            step += 1
        
        self.setValue(val)


class ScientificValidator(QValidator):
    """validator for scientific notation"""
    
    def __init__(self, minimum, maximum, decimals, prefix, suffix, parent=None):
        super().__init__(parent)
        self._minimum = minimum
        self._maximum = maximum
        self._decimals = decimals
        self._prefix = prefix if prefix else ""
        self._suffix = suffix if suffix else ""
        self.setLocale(QLocale(QLocale.English, QLocale.UnitedStates))
    
    def validate(self, text, ndx):
        return validateScientific(
            text, ndx,
            self._minimum, self._maximum,
            self._prefix, self._suffix,
            self._decimals,
            self.parent().hasFocus(),
        )

    def fixup(self, text):
        if not text:
            return 0
        number = text
        prefix = self._prefix if self._prefix else ""
        suffix = self._suffix if self._suffix else ""
        if prefix:
            number = number.removeprefix(prefix)
        if suffix:
            number = number.removesuffix(suffix)

        val = float(number)
        if val < self._minimum:
            val = self._minimum
        elif val > self._maximum:
            val = self._maximum
        
        mant, char = getMantissaCharacteristic(val, decimals=self._decimals)
        
        fmt = "%%.%ife%%i" % self._decimals
        
        return prefix + (fmt % (mant, char)) + suffix


class ScientificSpinBox(QDoubleSpinBox):
    """spinbox for floating point values in scientific notation"""
    def __init__(
        self,
        minimum=0,
        maximum=100,
        decimals=2,
        prefix=None,
        maxAbsoluteCharacteristic=None,
        stepMultiplier=1,
        suffix=None,
        default=None,
        tooltip=None, 
        mapping=None,
        parent=None,
    ):
        super().__init__(parent)
        if maximum < minimum:
            raise ValueError("maximum < minimum")
        if maxAbsoluteCharacteristic:
            assert(maxAbsoluteCharacteristic > 0)
        self.maxAbsoluteCharacteristic = maxAbsoluteCharacteristic
        assert(stepMultiplier > 0)
        self.stepMultiplier = stepMultiplier
        self.setMinimum(minimum)
        self.setMaximum(maximum)
        self.mapping = mapping
        if default is None:
            try:
                min_char = int(np.log10(abs(minimum)))
            # I guess newer versions of numpy do OverflowError instead of ValueError
            except (OverflowError, ValueError):
                min_char = 0
            min_mant = minimum / (10 ** min_char)
            if min_mant < 1:
                min_mant *= 10
                min_char -= 1
            try:
                max_char = int(np.log10(abs(maximum)))
            except ValueError:
                max_char = 0
            max_mant = maximum / (10 ** max_char)
            if max_mant < 1:
                max_mant *= 10
                max_char -= 1
            
            mean_mant = 0.5 * (max_mant + min_mant)
            mean_char = 0.5 * (max_char + min_char)
            default = mean_mant * 10 ** (mean_char)
        
        self.setValue(default)
        if tooltip is not None:
            self.setToolTip(tooltip)
        if prefix:
            self.setPrefix(prefix)
        if suffix:
            self.setSuffix(suffix)
    
        self._validator = ScientificValidator(
            minimum,
            maximum,
            decimals,
            self.prefix(),
            self.suffix(),
            self.lineEdit(),
        )
        self.lineEdit().setValidator(self._validator)
        self.setDecimals(decimals)

    def setMinimum(self, value):
        self._minimum = value
        self.lineEdit().validator()._minimum = value
        super().setMinimum(value)

    def setMaximum(self, value):
        self._maximum = value
        self.lineEdit().validator()._maximum = value
        super().setMaximum(value)

    def setDecimals(self, value):
        super().setDecimals(value)
        self.lineEdit().validator()._decimals = value

    def minimum(self):
        return self._minimum

    def maximum(self):
        return self._maximum

    def valueFromText(self, text):
        if self.prefix():
            text = text.removeprefix(self.prefix())
        if self.suffix():
            text = text.removesuffix(self.suffix())
        return float(text)
    
    def textFromValue(self, value):
        """
        :param float value: floating point number
        
        :returns: string for floating point number; according to the 
            Qt6 documentation, the string should not include the prefix
            or suffix
        :rtype: str
        """
        # split value into characteristic and mantissa
        mantissa, characteristic = self.getMantissaCharacteristic(value)
        
        fmt = "%%.%ife%%i" % self.decimals()
        out = fmt % (mantissa, characteristic)
        return out
    
    def validate(self, text, ndx):
        return validateScientific(
            text, ndx,
            self.minimum(), self.maximum(), 
            self.prefix(), self.suffix(),
            self.decimals(),
            self.lineEdit().hasFocus(),
        )
    
    def fixup(self, value):
        return
    
    def stepBy(self, n):
        if n < 0:
            for i in range(0, abs(n)):
                self.stepDown()
        elif n > 0:
            for i in range(0, n):
                self.stepUp()
    
    def getMantissaCharacteristic(self, value=None):
        if value is None:
            value = self._unmappedValue()
        return getMantissaCharacteristic(value, decimals=self.decimals())
    
    def stepUp(self):
        value = self._unmappedValue()
        mantissa, characteristic = self.getMantissaCharacteristic()

        characteristic -= 1
        value = value + self.stepMultiplier * 10 ** characteristic
        mantissa, characteristic = self.getMantissaCharacteristic(value)
        if self.maxAbsoluteCharacteristic and (
            value < 0 and abs(characteristic) > self.maxAbsoluteCharacteristic
        ):
            value = 0

        self.setValue(min(value, self.maximum()))

    def stepDown(self):
        value = self._unmappedValue()
        mantissa, characteristic = self.getMantissaCharacteristic()

        characteristic -= 1
        value = value - self.stepMultiplier * 10 ** characteristic
        mantissa, characteristic = self.getMantissaCharacteristic(value)
        if self.maxAbsoluteCharacteristic and (
            value > 0 and abs(characteristic) > self.maxAbsoluteCharacteristic
        ):
            value = 0

        self.setValue(max(value, self.minimum()))
    
    def _unmappedValue(self):
        text = self.text()
        text = text.replace(self.prefix(), "", 1)
        text = text[::-1].replace(self.suffix()[::-1], "", 1)[::-1]
        try:
            val = float(text)
        except ValueError:
            val = 0
        return val
    
    def value(self):
        val = self._unmappedValue()
        if self.mapping:
            return self.mapping(val)
        return val

    def setValue(self, value):
        sendSignal = False

        mantissa, characteristic = self.getMantissaCharacteristic(value)

        value = mantissa * 10 ** characteristic
        
        if value != self._unmappedValue():
            sendSignal = True

        self.lineEdit().setText(
            self.prefix() +
            self.textFromValue(value) +
            self.suffix()
        )

