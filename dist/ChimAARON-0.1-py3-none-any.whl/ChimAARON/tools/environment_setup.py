import ChimAARON
import os
import json

from chimerax.core.tools import ToolInstance
from chimerax.ui.gui import MainToolWindow, ChildToolWindow

from PyQt5.QtWidgets import QLabel, QLineEdit, QGridLayout, QPushButton, QTabWidget
        
class EnvironmentSetup(ToolInstance):
    #XML_TAG ChimeraX :: Tool :: Environment Setup :: ChimAARON :: Set environment variables for 
    SESSION_ENDURING = False
    SESSION_SAVE = False         
    display_name = "The Alchemist"
    
    def __init__(self, session, name):       
        super().__init__(session, name)
        
        self.tool_window = MainToolWindow(self)

        self._build_ui()

    def _build_ui(self):
        layout = QGridLayout()
        
        self.tool_window.ui_area.setLayout(layout)

        self.tool_window.manage('side')